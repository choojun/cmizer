################################################################################
Cmizer 2.0.2.5 (The LTSpice Edition for Windows)
For more details, visit us at http://cmizer.java.net
################################################################################
################################################################################

Please follow the installation instructions, at URL https://java.net/projects/cmizer/pages/Home#Installation , before start using the Cmizer.

Happy trying :D

Prepared by choojun
2013-05-28
