java -jar cmizer2.1.3.6.jar negblpfsk
