################################################################################
Cmizer 2.0.0.0 (LTSpice Edition)
For more details, visit us at http://cmizer.java.net
################################################################################
################################################################################

Please install the following software before start using the Cmizer:
1. LTSpice, http://www.linear.com/designtools/software/
2. Java Runtime Engine (JRE) or Java Development Kit (JDK) version 1.6, http://www.oracle.com/technetwork/java/javase/downloads/index.html
3. Open your "Command Prompt" in your Windows, change directory to particular <circuit_design>, and execute the run_<circuit_design>.bat file.
4. Examine the range of input variables and objectives.
5. Configure the Cmizer especially the MOEA setting before click on the "Run Now" button.


This version bundled with 5 <circuit design>s as follows.

[Removed] Fifth-Order Unity-Gain Bessel High-Pass3
[Removed] renamed to fohpf

Neg Unity Gain 100k MFB Butter LP Filter [1][1][1] ac
renamed to negblpf

Neg Unity Gain 100k SK Butter LP Filter [1][1][1] ac
renamed to negblpfsk

Pos Unity Gain 100k MFB Butter LP Filter [1][1][1] ac
renamed to posblpf

Pos Unity Gain 100k SK Butter LP Filter [1][1][1] ac
renamed to posblpfsk

Third-Order Unity-Gain Bessel High-Pass1
renamed to tohpf




Happy trying :D


Prepared by choojun
2013-05-09