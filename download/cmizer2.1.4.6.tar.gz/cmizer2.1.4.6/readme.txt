################################################################################
Cmizer 2.1.4.6 (The NGSpice Edition for Linux)
For more details, visit us at http://cmizer.java.net
################################################################################
################################################################################

Please follow the installation instructions, at URL https://java.net/projects/cmizer/pages/Home#Installation , before start using the Cmizer.

Happy trying :D

Prepared by choojun
2013-10-05
